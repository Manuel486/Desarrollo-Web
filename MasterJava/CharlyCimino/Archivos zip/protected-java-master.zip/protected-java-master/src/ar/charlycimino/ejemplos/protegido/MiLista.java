package ar.charlycimino.ejemplos.protegido;

import java.util.ArrayList;

/**
 *
 * @author Charly Cimino Aprendé más Java en mi canal:
 * https://www.youtube.com/c/CharlyCimino Encontrá más código en mi repo de
 * GitHub: https://github.com/CharlyCimino
 */
public class MiLista extends ArrayList {

    public MiLista() {

        // No heredamos ningún atributo de ArrayList porque son privados.
    }

}
